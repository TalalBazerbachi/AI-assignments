#This function generates trace files
def writeTrace(fName, trained, testData, trained_prop):
    outputFile = open(fName,"a")
    for i in range(len(trained)):
        #choose proper probability cell in train_prop array 
        trained_prop_i=1
        if trained[i] == 'no':
            trained_prop_i = 0

        #form output string
        result = str(testData['tweet_id'][i]) + "  " + trained[i] + "  " + "{:.5f}".format(float(trained_prop[i][trained_prop_i])) + "  " + testData['q1_label'][i] + "  " + ('correct' if trained[i] == testData['q1_label'][i] else 'wrong') + "\n"
        outputFile.write(result)

    #close trace output file
    outputFile.close()