-- This's a submission for A3 - SOEN472 --

Outputs folder contains all the required outputs. The only difference between Outputs and original outputted trace_NB-BOW-FV & trace_NB-BOW-OV folders is the IDs for the tweets. In Outputs, the IDs are identical to the ones available on Moodle.

GitHub: https://github.com/t98b/AI-assignments
Presentation Slides: https://docs.google.com/presentation/d/1COOUTGhrh2DlYmW4ltwXUcRGB9Ns7GLFNQKvTkjgONc/edit?usp=sharing

Thank You,
Hani &Talal